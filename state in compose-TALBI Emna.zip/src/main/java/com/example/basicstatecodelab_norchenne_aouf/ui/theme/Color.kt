package com.example.basicstatecodelab_norchenne_aouf.ui.theme

import androidx.compose.ui.graphics.Color

val Blue80 = Color(0xFF60CDF0)
val BlueGrey80 = Color(0xFF3D81A0)
val Pink80 = Color(0xFFCB93F3)

val Blue40 = Color(0xFF0071D3)
val BlueGrey40 = Color(0xFF75DCEE)
val IceBlue40 = Color(0xFF85A0EC)